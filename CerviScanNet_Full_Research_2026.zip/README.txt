CerviScanNet Full Research Framework (2026)
-------------------------------------------------
This package includes the full Jupyter notebook for binary and multi-class cervical cytology classification
with CerviScan-Net and baseline deep learning models.

Contents:
- CerviScanNet_Full_Research_2026.ipynb : Full notebook
- results/ : Grad-CAM heatmaps and visualizations
- checkpoints/ : Model weights after training

Compatible with TensorFlow 2.14 / Keras 3.0
