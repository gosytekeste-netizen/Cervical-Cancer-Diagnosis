
CerviScan-Net Research Package (2026)
--------------------------------------
TensorFlow 2.14 / Keras 3.0 | Colab-Optimized

Contents:
 - Full research notebook (.ipynb)
 - Figures 4 & 5 (PNG)
 - Tables 4 & 5 (CSV + LaTeX)
 - Model summary + MIT license

Usage:
1. Open the .ipynb file in Google Colab
2. Mount Google Drive (`drive.mount('/content/drive')`)
3. Train / evaluate CerviScan-Net using your datasets
4. Outputs saved to: /MyDrive/CerviScanNet/

Citation:
If used in research, please cite:
   "CerviScan-Net: Hybrid SwinV2–EffNetV2–BiLSTM for Cervical Cancer Detection, 2026 (Under Review)."
