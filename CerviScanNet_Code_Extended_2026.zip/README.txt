
CerviScan-Net Extended Code Package (2026)
------------------------------------------
Includes:
- Proposed CerviScan-Net (SwinV2 + EffNetV2 + BiLSTM-Attn)
- Baselines: ResNet50+LSTM, VGG19+Transformer, DenseNet121, Xception, InceptionV3

Framework: TensorFlow 2.14 / Keras 3.0
All models ready for direct training using `train_model.py`.
