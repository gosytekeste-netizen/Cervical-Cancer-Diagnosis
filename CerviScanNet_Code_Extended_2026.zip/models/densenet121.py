
from tensorflow import keras
from tensorflow.keras import layers

def build_densenet121(input_shape=(224, 224, 3), num_classes=2):
    base = keras.applications.DenseNet121(include_top=False, input_shape=input_shape, weights='imagenet')
    base.trainable = False
    x = base.output
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(256, activation='relu')(x)
    out = layers.Dense(num_classes, activation='softmax')(x)
    return keras.Model(base.input, out, name="DenseNet121_Baseline")
