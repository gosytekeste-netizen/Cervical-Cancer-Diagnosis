
from tensorflow import keras
from tensorflow.keras import layers

def build_xception_net(input_shape=(224, 224, 3), num_classes=2):
    base = keras.applications.Xception(include_top=False, input_shape=input_shape, weights='imagenet')
    base.trainable = False
    x = base.output
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(num_classes, activation='softmax')(x)
    return keras.Model(base.input, out, name="Xception_Baseline")
